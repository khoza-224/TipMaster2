package com.example.tipmaster;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText billAmountEditText;
    private Spinner tipPercentageSpinner;
    private TextView tipAmountTextView;

    private final double[] tipPercentages = {0.10, 0.15, 0.20, 0.25};
    private final String[] tipPercentageStrings = {"10%", "15%", "20%", "25%"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        billAmountEditText = findViewById(R.id.bill_amount_edit_text);
        tipPercentageSpinner = findViewById(R.id.tip_percentage_spinner);
        Button calculateTipButton = findViewById(R.id.calculate_tip_button);
        tipAmountTextView = findViewById(R.id.tip_amount_text_view);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tipPercentageStrings);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tipPercentageSpinner.setAdapter(adapter);

        calculateTipButton.setOnClickListener(v -> calculateTip());
    }

    @SuppressLint({"DefaultLocale", "SetTextI18n"})
    private void calculateTip() {
        try {
            double billAmount = Double.parseDouble(billAmountEditText.getText().toString());
            int selectedTipPercentageIndex = tipPercentageSpinner.getSelectedItemPosition();
            double tipPercentage = tipPercentages[selectedTipPercentageIndex];
            double tipAmount = billAmount * tipPercentage;
            tipAmountTextView.setText(String.format("Tip Amount: $%.2f", tipAmount));
        } catch (NumberFormatException e) {
            tipAmountTextView.setText("Invalid bill amount");
        }
    }
}
